#ifndef GED_H
#define GED_H

arma::vec std_Score(double dY, arma::vec vTheta);
arma::mat std_IM( arma::vec vTheta);
double dGED(double dY, double dMu, double dSD , double dNu, bool bLog=false);
double pSTD(double dY, double dMu, double dSD , double dNu);
double qSTD(double dP, double dMu, double dSD , double dNu);
double rSTD(double dMu, double dSD , double dNu);
arma::vec mSTD(double dMu, double dSD, double dNu);
#endif
