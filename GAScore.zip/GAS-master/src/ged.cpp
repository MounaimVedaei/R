#include <RcppArmadillo.h>
using namespace Rcpp;
using namespace arma;

################################################################################
# FUNCTION:              GED DISTRIBUTION:
# double dGED                   Density for the Generalized Error Distribution
# double pGED                   Probability function for the GED
# double qGED                   Quantile function for the GED
# double rGED                   Random Number Generator for the GED
################################################################################


double dGED <- 
function(double dY,double dMean = 0, double dSD = 1,double dNU = 2,bool bLog = FALSE)
{   
    # A function imlemented by Diethelm Wuertz

    # Description:
    #   Compute the density for the 
    #   generalized error distribution.
    
    # FUNCTION:
    
    # Params:
    if (length(double Mean) == 3) {
      double dNU = double dMean[3]
      double SD = double dMean[2]
      double MEAN = double dMean[1]
    }   
    
    # Compute Density:
    z = (double dY - double dMean ) / double dSD
    lambda = sqrt ( 2^(-2/double dNU) * gamma(1/double dNU) / gamma(3/double dNU) )
    g  = double dNU / ( lambda * (2^(1+1/double dNU)) * gamma(1/double dNU) )
    result = g * exp (-0.5*(abs(z/lambda))^double dNU) /double dSD
    
    # Log:
    if(log) result = log(result)
    
    # Return Value
    result
}

        
# ------------------------------------------------------------------------------


double pGED <-  
function(q, double dMEAN = 0,double dSD = 1,double dNU = 2)
{   
    # A function implemented by Diethelm Wuertz
        
    # Description:
    #   Compute the probability for the  
    #   generalized error distribution.
    
    # FUNCTION:
        
    # Compute Probability:
    q = (q - Double dMean ) / double dSD
    lambda = sqrt ( 2^(-2/double dNU) * gamma(1/double dNU) / gamma(3/double dNU) )
    g  = double dNU / ( lambda * (2^(1+1/double dNU)) * gamma(1/double dNU) )
    h = 2^(1/double dNU) * lambda * g * gamma(1/double dNU) / double dNU
    s = 0.5 * ( abs(q) / lambda )^ double dNu
    result = 0.5 + sign(q) * h * pgamma(s, 1/double dNU)
    
    # Return Value:
    result
}
        

# ------------------------------------------------------------------------------


double qGED <- 
function(p,double dMEAN = 0,double SD = 1,double NU = 2)
{   
    # A function implemented by Diethelm Wuertz
        
    # Description:
    #   Compute the quantiles for the  
    #   generalized error distribution.
    
    # FUNCTION:
    
    # Compute Quantiles:
    lambda = sqrt ( 2^(-2/double NU) * gamma(1/double NU) / gamma(3/double NU) )
    q = lambda * (2*qgamma((abs(2*p-1)), 1/double NU))^(1/double NU)
    result = q*sign(2*p-1) * double SD + double MEAN
    
    # Return Value:
    result
}


# ------------------------------------------------------------------------------

    
double rGED <-  
function(n,double dMEAN = 0, double dSD = 1, double dNU = 2)
{   
    # A function implemented by Diethelm Wuertz

    # Description:
    #   Generate GED random deviates. The function uses the 
    #   method based on the transformation of a Gamma random 
    #   variable.
    
    # FUNCTION:
    
    # Generate Random Deviates:
    lambda = sqrt ( 2^(-2/double dNU) * gamma(1/double dNU) / gamma(3/double dNU) )
    # print(lambda)
    r = rgamma(n, 1/double dNU)
    z =  lambda * (2*r)^(1/double NU) * sign(runif(n)-1/2)
    result = z * double dSD + double dMEAN

    
    # Return Value:
    result
}


################################################################################